<?php
    //Conexion a base de datos
    $user="root";
    $password="";
    $server="localhost";
    $db="pruebaTecnica";

    $correcto = true;
    $conexion=mysqli_connect($server,$user,$password,$db) or die ("Error...". mysqli_error());
    $trans = $conexion->query("UPDATE usuarios SET saldo = 0 where id= " . $_POST['id']) ;

    $trans_a = $conexion->query("UPDATE usuarios SET saldo = (saldo + ". $_POST['valor'] . ") where id= " . $_POST['trasn_a']) ;


    if($trans != true && $trans_a != true){
        $correcto = false;
    }

    echo $correcto;
    return;
?>