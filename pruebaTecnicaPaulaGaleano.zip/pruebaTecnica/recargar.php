<?php
    //Conexion a base de datos
    $user="root";
    $password="";
    $server="localhost";
    $db="pruebaTecnica";

    $correcto = true;
    $conexion=mysqli_connect($server,$user,$password,$db) or die ("Error...". mysqli_error());
    $recargar_saldo = $conexion->query("UPDATE usuarios SET saldo = " . $_POST['saldo'] .  " WHERE  id =" . $_POST['id_saldo']) ;
    if(!$recargar_saldo){
        $correcto = false;
    }

    echo $correcto;
    return;
?>