//Script para el uso de index.php
// Paula Galeano
// 27/04/2021



/**
 * Abre el modal que permite consultar los datos de un usuario
 * @author paula.galeano
 * @since 27/04/2021
 */
function consultar(id){
    $('#consultar').show();
    $.ajax({
        url: "consultar.php",
        type: "POST",
        data: {'id' : id},
        success: function(resp) {
            var data = JSON.parse(resp);
            var doc = document.getElementById('foto_con')
            doc.src = data['foto'];
            $("#nombres_con").val(data['nombre'] + " " + data['apellido']);
            $("#saldo_con").val(data['saldo']);
        }
    });
}

/**
 * Abre el modal que permite visualizar y modificar el saldo
 * @author paula.galeano
 * @since 27/04/2021
 */
function recargar(id){
    $('#recargar').show();
    $("#irecargar").val(id);
    $.ajax({
        url: "consultar.php",
        type: "POST",
        data: {'id' : id},
        success: function(resp) {
            var data = JSON.parse(resp);
            var doc = document.getElementById('foto_rec')
            doc.src = data['foto'];
            $("#nombres_rec").val(data['nombre'] + " " + data['apellido']);
            $("#saldo_rec").val(data['saldo']);
        }
    });
}

/**
 * Abre el modal que permite actualizar el saldo de un usuario
 * @author paula.galeano
 * @since 27/04/2021
 */
function guardar(){
    if($("#saldo_rec").val() != "" && $("#saldo_rec").val() != null){
        $.ajax({
            url: "recargar.php",
            type: "POST",
            data: {
                'id_saldo' : $("#irecargar").val(),
                'saldo' : $("#saldo_rec").val(),
            },
            success: function(resp) {
                console.log(resp);
                if(resp == 1){
                    alert("Saldo actualizado correctamente.");
                    location.reload();
                }else{
                    alert("Error al actualizar el saldo.");
                }
            }
        });
    }else{
        alert("El saldo no puede estár vacio");
    }
}

/**
 * Abre el modal que permite transferir dinero entre cuentas
 * @author paula.galeano
 * @since 27/04/2021
 */
function transferir(id){
    $('#transferir').show();
    $("#ntransferir").val(id);
    $.ajax({
        url: "consultar.php",
        type: "POST",
        data: {'id' : id},
        success: function(resp) {
            var data = JSON.parse(resp);
            $("#nombres_tran").val(data['nombre'] + " " + data['apellido']);
            $("#saldo_tran").val(data['saldo']);
        }
    });
}


/**
 * Abre el modal que permite transferir el dinero a otra cuenta
 * @author paula.galeano
 * @since 27/04/2021
 */
function guardar2(){
    $.ajax({
        url: "transferir.php",
        type: "POST",
        data: {
            'trasn_a' : $("#trans_a").val(),
            'id' : $("#ntransferir").val(),
            'valor' : $("#saldo_tran").val(),
        },
        success: function(resp) {
            console.log(resp);
            if(resp == 1){
                alert("Transferencia exitosa.");
                location.reload();
            }else{
                alert("Error al hacer la transferencia.");
            }
        }
    });
}
  