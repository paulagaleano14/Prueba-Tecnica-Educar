<!--
  Autor: Paula Daniela Galeano Soto
  Nota: Prueba técnica
  Fecha: 27/04/2021
--> 

<!--Incluir estilos bootstrap--> 
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<!--Incluir scripts--> 
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="index.js"></script>
<!--Incluir iconos--> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!--Consulta a la base de datos--> 
<?php
    $user="root";
    $password="";
    $server="localhost";
    $db="pruebaTecnica";

    $conexion=mysqli_connect($server,$user,$password,$db) or die ("Error...". mysqli_error());
    $consulta = $conexion->query("SELECT * from usuarios  ORDER BY id ASC");
 ?>

<!-- LISTA DE USUARIOS  --> 
<section id="listar">
  <div class="container-fluid mt-5">
    <div class="row justify-content-center">
      <table class="table table-bordered table-sm col-md-9">
        <thead style="background-color: rgb(124, 15, 15); color: white;"  class="text-center">
          <th style="width:5%">Foto</th>
          <th>#</th>
          <th>Nombre y Apellido</th>
          <th>Saldo</th>
          <th style="width:10%">Perfil del usuario</th>
          <th style="width:10%">Recargar Saldo</th>
          <th style="width:10%">Transferir dinero</th>
        </thead>c
        <tbody> 
          <?php while($listar = mysqli_fetch_array($consulta)){ ?>
            <tr class="text-center">
                <td><img value="imagen" class="card-img-top" src="<?php echo $listar['foto']; ?>"></td>
                <td><?php echo $listar['id']; ?></td>
                <td><?php echo $listar['nombre']. " " .$listar['apellido'] ?></td>
                <td><?php echo $listar['saldo']; ?></td>
                <td><button class="btn btn-success" data-toggle="modal" data-target="#consultar" onclick="consultar(<?php echo $listar['id'] ?>)">Ver perfil</button></td>
                <td><button class="btn btn-danger" data-toggle="modal" data-target="#recargar" id="irecargar" name="irecargar" onclick="recargar(<?php echo $listar['id'] ?>)">Recargar Saldo</button></td>
                <td><button class="btn btn-warning" data-toggle="modal" data-target="#transferir" id="ntransferir" name="ntransferir" onclick="transferir(<?php echo $listar['id'] ?>)">Transferir</button></td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
    
    <p class="text-center">Creado por: Paula Daniela Galeano Soto</p>
  </section>

<!-- Modal consultar -->
<div class="modal fade" id="consultar" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Perfil del usuario</h5>
        </div>
        <div class="modal-body">
          <div class="container">
              <div class="" >
                  <label>Foto:</label>
                  <div style="padding-left: 20%">
                    <img style="height : 100%; width: 70%; " class="form-control" src="" id="foto_con" name="foto_con" disabled placeholder="Foto de perfil"/>
                  </div>
              </div><br>
              <div class="" >
                  <label>Nombre y Apellido:</label>
                  <input type="text" class="form-control" id="nombres_con" name ="nombres_con" placeholder="Nombre y apellido" disabled/>
              </div><br>
              <div class="">
                  <label>Saldo:</label>
                  <input type="number" class="form-control" id="saldo_con" name="saldo_con" placeholder="Saldo" disabled/>
              </div><br>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
    </div>
</div>

<!-- Modal recargar -->
<div class="modal fade" id="recargar" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Recargar mi cuenta</h5>
        </div>
        <div class="modal-body">
        <div class="container">
            <div class="" >
            <label>Foto:</label>
                <div style="padding-left: 20%">
                    <img style="height : 100%; width: 70%; " class="form-control" src="" id="foto_rec" name="foto_rec" disabled placeholder="Foto de perfil"/>
                </div>
            </div><br>
            <div class="" >
            <label>Nombre y Apellido:</label>
            <input type="text" class="form-control" id="nombres_rec" name ="nombres_rec" placeholder="Nombre y apellido" disabled/>
            </div><br>
            <div class="" >
            <label>Saldo:</label>
            <input type="number" class="form-control" id="saldo_rec" name="saldo_rec" />
            </div><br>
        </div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-success" onclick="guardar()">Guardar</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
    </div>
</div>

<!-- Modal transferir -->
<div class="modal fade" id="transferir" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Transferir dinero</h5>
        </div>
        <div class="modal-body">
            <div class="container">
                <div class="" >
                    <label>Nombre y Apellido:</label>
                    <input type="text" class="form-control" id="nombres_tran" name ="nombres_tran"  placeholder="Nombre y apellido" disabled/>
                </div><br>
                <div class="" >
                    <label>Saldo:</label>
                    <input type="number" class="form-control"  id="saldo_tran" name="saldo_tran" disabled/>
                </div><br>

                <label class="text-center">Transferir a:</label>

                <br>
                <select class="custom-select" nombreCampo="trans_a" name="trans_a" id="trans_a">
                    <option selected value="">Seleccione</option>
                    <option value="1">Paula Galeano</option>
                    <option value="2">Lina Restrepo</option>
                    <option value="3">Daniela Soto</option>
                    <option value="4">Laura Acosta</option>
                    <option value="5">Santiago López</option>
                    <option value="6">Angie Cely</option>
                    <option value="7">Jhordan Puentes</option>
                    <option value="8">Catalina Galeano</option>
                </select>

            </div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-success" onclick="guardar2()">Guardar</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
    </div>
</div>