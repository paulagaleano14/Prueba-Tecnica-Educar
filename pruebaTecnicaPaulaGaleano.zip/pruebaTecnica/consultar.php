<?php
    //Conexion a base de datos
    $user="root";
    $password="";
    $server="localhost";
    $db="pruebaTecnica";

    $conexion=mysqli_connect($server,$user,$password,$db) or die ("Error...". mysqli_error());
    $consulta_datos = $conexion->query("SELECT * FROM usuarios WHERE id =" . $_POST['id']) ;

    $listar = mysqli_fetch_array($consulta_datos);
    echo json_encode($listar);
    return;

 ?>